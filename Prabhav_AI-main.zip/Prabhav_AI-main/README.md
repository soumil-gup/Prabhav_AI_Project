Prabhav AI – AI-Powered Influencer Marketing Platform

Prabhav AI is a full-stack influencer marketing platform that streamlines the collaboration process between brands and creators. The platform enables brands to discover influencers, evaluate brand fit, create and simulate campaigns, manage collaborations, and leverage AI-powered insights to make data-driven marketing decisions.

---

## Features

### Authentication

* Secure user authentication
* Role-based access (Brand / Influencer)
* Protected API endpoints

### Brand Dashboard

* Manage brand profile
* View campaign analytics
* Monitor collaborations
* Track campaign performance

### Influencer Discovery

* Search influencers
* Filter by niche, category, engagement, and followers
* View influencer profiles
* AI-powered brand fit recommendations

### Collaboration Management

* Create collaboration requests
* Track collaboration status
* Manage active partnerships
* Campaign history

### Campaign Management

* Create campaigns
* Define campaign goals
* Manage campaign budget
* Track campaign lifecycle

### AI-Powered Features

* Brand fit analysis
* Market intelligence
* Campaign performance simulation
* Recommendation engine
* Profile intelligence
* AI advisor for marketing insights

### Analytics

* Campaign statistics
* Collaboration metrics
* Influencer performance insights
* Engagement analysis

---

# Tech Stack

## Frontend

* React.js
* Vite
* JavaScript
* CSS

## Backend

* FastAPI
* Python

## Database

* SQLite

## AI / Services

* Recommendation Engine
* Brand Fit Analysis
* Profile Intelligence
* Campaign Simulation
* Market Intelligence
* AI Advisor

---

# Project Structure

```text
Project_1-main
│
├── backend
│   ├── app
│   │   ├── core
│   │   ├── routers
│   │   ├── services
│   │   ├── models.py
│   │   ├── schemas.py
│   │   └── main.py
│   │
│   └── tests
│
├── frontend
│   ├── src
│   │   ├── components
│   │   ├── pages
│   │   ├── assets
│   │   └── App.jsx
│   │
│   └── package.json
│
├── prabhav_ai.db
├── requirements.txt
├── .env.example
└── README.md
```

---

# Installation

## 1. Clone the Repository

```bash
git clone https://github.com/your-username/prabhav-ai.git
cd prabhav-ai
```

---

## 2. Backend Setup

Create a virtual environment:

```bash
python -m venv venv
```

Activate it (Windows):

```bash
venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Run the backend:

```bash
uvicorn backend.app.main:app --reload
```

Backend runs at:

```
http://127.0.0.1:8000
```

Swagger documentation:

```
http://127.0.0.1:8000/docs
```

---

## 3. Frontend Setup

Navigate to the frontend directory:

```bash
cd frontend
```

Install dependencies:

```bash
npm install
```

Run the development server:

```bash
npm run dev
```

Frontend runs at:

```
http://localhost:5173
```

---

# Database

The project uses SQLite for local development.

Database file:

```
prabhav_ai.db
```

Main entities include:

* Users
* Brand Profiles
* Influencer Profiles
* Social Platform Data
* Campaigns
* Collaborations
* Campaign Simulations

---

# Learning Outcomes

This project demonstrates:

* Full-stack application development
* REST API design using FastAPI
* React-based frontend architecture
* Authentication and authorization
* Database modeling
* AI-assisted recommendation systems
* Campaign management workflows
* Clean project organization
* Frontend–backend integration

---

# Business Problem

Brands often spend significant time manually identifying suitable influencers, evaluating campaign compatibility, and tracking collaborations. Prabhav AI centralizes these workflows into a single platform by providing AI-assisted influencer discovery, campaign planning, collaboration management, and performance insights, enabling faster and more informed marketing decisions.

---


# License

This project is licensed under the MIT License.

---

# Author

**Soumil Gupta**
